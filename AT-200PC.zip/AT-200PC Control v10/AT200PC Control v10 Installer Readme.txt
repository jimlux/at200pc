AT200PC Control Installer Readme.txt
------------------------------------

Contained in the zip file, AT200PC Control v10 Installer.zip are
the files required to install the AT200 PC Control version 1.0 
software binaries. 

There are four files in this zip archive:

AT200PC Control v10 Installer.msi -- Installer data
Setup.exe -- Installer executable
Setup.ini -- Installer data
AT200PC Control Installer Readme.txt -- This file



Before installing this software, please uninstall any previous
versions of AT200PC Control. 

To install AT200PC Control, version 1.0, do the following:

Double-click on the AT200PC Control v10 Installer.exe icon
to install the AT200PC Control software, version 1.0.

A guided setup will help you install the software. 

